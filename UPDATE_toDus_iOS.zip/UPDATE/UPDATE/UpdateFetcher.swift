//
//  UpdateFetcher.swift
//  UPDATE
//
//  Created by Elier Ayala on 1/15/21.
//  Copyright © 2021 Elier Ayala. All rights reserved.
//

import UIKit

public class UpdateFetcher: ObservableObject {
@Published var verse: Welcome?

init(){
    load()
}

func load() {
    let url = URL(string: "http://192.168.42.129:8080/update.json")!

    URLSession.shared.dataTask(with: url) {(data,response,error) in
        do {
            if let d = data {
                
                let webData = try JSONDecoder().decode(Welcome.self, from: d)
                DispatchQueue.main.async {
                    self.verse = webData
                }
            }else {
                print("No Data")
            }
        } catch {
            print ("Error here")
        }

    }.resume()
}}


// MARK: - Welcome
struct Welcome: Codable {
    let verse: Verse
}

// MARK: - Verse
struct Verse: Codable {
    let details: Details
}

// MARK: - Details
struct Details: Codable {
    let text, version, updateURL: String
    
}

