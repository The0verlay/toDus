//
//  ImageView.swift
//  UPDATE
//
//  Created by Elier Ayala on 1/15/21.
//  Copyright © 2021 Elier Ayala. All rights reserved.
//

import SwiftUI

struct ImageView: View {
    var body: some View {
        
         Image("update")
        .resizable()
            .frame(width: 300.0, height: 300.0)
        .clipShape(Circle())
        .overlay(Circle().stroke(Color.white, lineWidth: 4))
        .shadow(radius: 7)
        
    }
}

struct ImageView_Previews: PreviewProvider {
    static var previews: some View {
        ImageView()
    }
}
