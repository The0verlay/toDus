//
//  SwiftUIView.swift
//  UPDATE
//
//  Created by Elier Ayala on 1/15/21.
//  Copyright © 2021 Elier Ayala. All rights reserved.
//

import SwiftUI


struct UpdateView: View {
    
     @ObservedObject var fetcher = UpdateFetcher()
    
    var body: some View {
            NavigationView{

                    VStack{
                        
                        Text("Hay una nueva Actualización")
                        
                        Spacer()
                        
                        ImageView()
                            .offset(y: -130)
                            .padding(.bottom, -130)
                        Spacer()
                        Button(action: {
                            if let url  = URL(string: self.fetcher.verse?.verse.details.updateURL ?? ""),
                                
                                UIApplication.shared.canOpenURL(url) {
                                
                                UIApplication.shared.open(url)
                            }
                            }) {
                            Text("Descargar")
                                .font(.headline)
                                .foregroundColor(.white)
                                .padding()
                                .frame(width: 225, height: 60)
                                .background(Color.red)
                                .cornerRadius(35.0)
                              
                        }
                        Divider()
                    }.padding()

                
                
                
            }
                   
            
        }
    }

struct UpdateView_Previews: PreviewProvider {
    static var previews: some View {
        UpdateView()
    }
}

