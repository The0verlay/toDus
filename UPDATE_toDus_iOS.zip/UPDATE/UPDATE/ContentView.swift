//
//  ContentView.swift
//  UPDATE
//
//  Created by Elier Ayala on 1/15/21.
//  Copyright © 2021 Elier Ayala. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    
@ObservedObject var fetcher = UpdateFetcher()
    
    var body: some View {
        
       VStack{
            
            if self.fetcher.verse?.verse.details.version == "1.0" {
                
                UpdateView()
            }
            else{
                NavigationView{
                    VStack{
                        Text("Chats")
                    }.navigationBarTitle("toDus")
                }
                
            }
        }
       

  
        
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

